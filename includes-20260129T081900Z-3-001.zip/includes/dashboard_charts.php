<script>
    // Views Chart
    const ctxViews = document.getElementById('viewsChart').getContext('2d');
    new Chart(ctxViews, {
        type: 'line',
        data: {
            labels: window.dashboardData.weekly.labels,
            datasets: [{
                label: 'Publications',
                data: window.dashboardData.weekly.data,
                borderColor: '#60b5ff',
                backgroundColor: 'rgba(96, 181, 255, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#60b5ff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1e293b',
                    padding: 12,
                    titleFont: { family: "'Plus Jakarta Sans', sans-serif", size: 13 },
                    bodyFont: { family: "'Plus Jakarta Sans', sans-serif", size: 12 },
                    cornerRadius: 8,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return context.parsed.y + ' Articles Published';
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9', borderDash: [5, 5] },
                    ticks: { callback: function(value) {if (value % 1 === 0) {return value;}}, font: { family: "'Plus Jakarta Sans', sans-serif", size: 11 }, color: '#94a3b8' },
                    border: { display: false }
                },
                x: {
                    grid: { display: false },
                    ticks: { font: { family: "'Plus Jakarta Sans', sans-serif", size: 11 }, color: '#94a3b8' },
                    border: { display: false }
                }
            }
        }
    });

    // Category Chart
    const ctxCat = document.getElementById('categoryChart').getContext('2d');
    new Chart(ctxCat, {
        type: 'doughnut',
        data: {
            labels: window.dashboardData.categories.labels,
            datasets: [{
                data: window.dashboardData.categories.data,
                backgroundColor: window.dashboardData.categories.colors,
                borderWidth: 0,
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: '#1e293b',
                    bodyFont: { family: "'Plus Jakarta Sans', sans-serif", size: 12 },
                    cornerRadius: 8
                }
            },
            cutout: '75%'
        }
    });
</script>
