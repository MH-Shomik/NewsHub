<?php
header('Content-Type: application/json');
require_once '../includes/db_connect.php';

// Helper to map DB categories to new Palette Colors
function getCategoryColor($slug) {
    // Returns Tailwind classes based on category slug
    $map = [
        'academic' => 'bg-cool_sky-500 text-white',
        'research' => 'bg-aquamarine-500 text-slate-900',
        'events'   => 'bg-tangerine_dream-500 text-white',
        'sports'   => 'bg-strawberry_red-500 text-white',
        'notice'   => 'bg-jasmine-400 text-slate-900',
    ];
    return $map[$slug] ?? 'bg-slate-700 text-white';
}

function getPlaceholderImage($category, $seed) {
    // Generates a relevant distinct placeholder color based on category
    // Using placehold.co with custom colors from our palette
    $colors = [
        'academic' => '60b5ff', // cool_sky
        'research' => '5ef2d5', // aquamarine
        'events' => 'f79d65',   // tangerine
        'sports' => 'f35252',   // strawberry
        'notice' => 'ffe588',   // jasmine
    ];
    $hex = $colors[$category] ?? 'cbd5e1';
    $textHex = ($category == 'notice' || $category == 'research') ? '0f172a' : 'ffffff';
    // Use placehold.co
    return "https://placehold.co/800x600/$hex/$textHex?text=" . urlencode(ucfirst($category) . "+Update");
}

$categorySlug = $_GET['category'] ?? '';

try {
    $sql = "
        SELECT n.*, c.name as category_name, c.slug as category_slug, u.full_name as author_name 
        FROM news n 
        JOIN categories c ON n.category_id = c.category_id 
        JOIN users u ON n.author_id = u.user_id 
        WHERE n.status = 'published' 
    ";
    
    $params = [];
    
    if (!empty($categorySlug) && $categorySlug !== 'all') {
        $sql .= " AND c.slug = :slug";
        $params[':slug'] = $categorySlug;
    }
    
    $sql .= " ORDER BY n.created_at DESC LIMIT 9";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $newsList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Process results to add computed fields
    foreach($newsList as $index => &$news) {
        $news['category_color'] = getCategoryColor($news['category_slug']);
        $news['placeholder_image'] = getPlaceholderImage($news['category_slug'], $index);
        
        // Use placeholder if image_url is missing
        if (empty($news['image_url'])) {
            $news['image_url'] = $news['placeholder_image'];
        }
        
        // Format date
        $news['formatted_date'] = date('M d', strtotime($news['created_at']));
        $news['formatted_views'] = number_format($news['views']);
        $news['excerpt'] = htmlspecialchars(substr(strip_tags($news['content']), 0, 100)) . '...';
        // Add author initial
        $news['author_initial'] = substr($news['author_name'], 0, 1);
    }
    
    echo json_encode(['status' => 'success', 'data' => $newsList]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
